/* =====================================================
   Erfan. — لایه داده (localStorage) + توابع کمکی مشترک
   بین سایت و پنل ادمین
   ===================================================== */
const Store = (() => {
  const KEY = 'erfan_db_v1';
  let mem = null;
  const clone = (o) => JSON.parse(JSON.stringify(o));

  function load() {
    let raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) {}
    mem = null;
    if (raw) { try { mem = JSON.parse(raw); } catch (e) { mem = null; } }
    if (!mem) { mem = clone(ERFAN_DEFAULTS); save(); }
    return mem;
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(mem)); } catch (e) {} }
  function reset() { mem = clone(ERFAN_DEFAULTS); save(); return mem; }
  function replace(obj) { mem = obj; save(); }

  const db = () => mem || load();
  const cat = (id) => db().categories.find((c) => c.id === id);
  const product = (id) => db().products.find((p) => p.id === id);

  /* قیمت و تخفیف: بیشترِ «تخفیف کالا» و «تخفیف سراسری» اعمال می‌شود */
  const discountPct = (p) => Math.min(90, Math.max(Number(p.discount) || 0, Number(db().settings.globalSale) || 0));
  const finalPrice = (p) => Math.round((p.price * (1 - discountPct(p) / 100)) / 1000) * 1000;

  const nf = new Intl.NumberFormat('fa-IR');
  const fmt = (n) => nf.format(Math.round(n));
  const toman = (n) => nf.format(Math.round(n)) + ' تومان';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function nextId(prefix) {
    let i = db().products.length + 1;
    while (db().products.some((p) => p.id === prefix + i)) i++;
    return prefix + i;
  }

  return { load, save, reset, replace, get db() { return db(); }, cat, product, discountPct, finalPrice, fmt, toman, esc, nextId };
})();
