/* =====================================================
   Erfan. — داده‌های پیش‌فرض فروشگاه
   (در اولین اجرا در localStorage کپی می‌شود)
   قیمت‌ها به تومان
   ===================================================== */
(function () {
  const P = (id, cat, name, brand, price, discount, stock, spec) =>
    ({ id, cat, name, brand, price, discount, stock, img: '', spec });

  const categories = [
    { id: 'cpu',     name: 'پردازنده (CPU)',       group: 'parts',  icon: '🧠' },
    { id: 'gpu',     name: 'کارت گرافیک (GPU)',    group: 'parts',  icon: '🎮' },
    { id: 'ram',     name: 'حافظه رم (RAM)',       group: 'parts',  icon: '💾' },
    { id: 'mb',      name: 'مادربرد',               group: 'parts',  icon: '🔌' },
    { id: 'storage', name: 'حافظه جانبی',           group: 'parts',  icon: '🗄️' },
    { id: 'cooler',  name: 'خنک‌کننده',             group: 'parts',  icon: '❄️' },
    { id: 'deco',    name: 'قطعات تزئینی',          group: 'parts',  icon: '✨' },
    { id: 'case',    name: 'کیس',                   group: 'parts',  icon: '🖥️' },
    { id: 'psu',     name: 'منبع تغذیه (پاور)',     group: 'parts',  icon: '⚡' },
    { id: 'periph',  name: 'تجهیزات جانبی',         group: 'periph', icon: '⌨️' },
    { id: 'net',     name: 'تجهیزات شبکه',          group: 'net',    icon: '📡' }
  ];

  const yn = ['بله', 'خیر'];
  const sockets = ['AM4', 'AM5', 'LGA1700', 'LGA1851'];
  const specSchema = {
    cpu: [
      { k: 'socket', label: 'سوکت', type: 'select', options: sockets },
      { k: 'cores', label: 'تعداد هسته', type: 'number' },
      { k: 'tdp', label: 'توان مصرفی (وات)', type: 'number' },
      { k: 'score', label: 'امتیاز عملکرد (۱ تا ۱۰۰)', type: 'number' },
      { k: 'igpu', label: 'گرافیک داخلی', type: 'select', options: yn }
    ],
    gpu: [
      { k: 'vram', label: 'حافظه (GB)', type: 'number' },
      { k: 'tdp', label: 'توان مصرفی (وات)', type: 'number' },
      { k: 'length', label: 'طول کارت (mm)', type: 'number' },
      { k: 'score', label: 'امتیاز عملکرد (۱ تا ۱۰۰)', type: 'number' }
    ],
    ram: [
      { k: 'type', label: 'نوع', type: 'select', options: ['DDR4', 'DDR5'] },
      { k: 'size', label: 'ظرفیت کل (GB)', type: 'number' },
      { k: 'speed', label: 'سرعت (MHz)', type: 'number' }
    ],
    mb: [
      { k: 'socket', label: 'سوکت', type: 'select', options: sockets },
      { k: 'ramType', label: 'نوع رم پشتیبانی‌شده', type: 'select', options: ['DDR4', 'DDR5'] },
      { k: 'form', label: 'فرم‌فاکتور', type: 'select', options: ['ATX', 'mATX', 'ITX'] },
      { k: 'chipset', label: 'چیپست', type: 'text' }
    ],
    storage: [
      { k: 'kind', label: 'نوع', type: 'select', options: ['NVMe SSD', 'SATA SSD', 'HDD', 'SSD اکسترنال', 'HDD اکسترنال'] },
      { k: 'size', label: 'ظرفیت (GB)', type: 'number' }
    ],
    cooler: [
      { k: 'ctype', label: 'نوع', type: 'select', options: ['هوایی', 'مایع'] },
      { k: 'sockets', label: 'سوکت‌های پشتیبانی‌شده (با ویرگول)', type: 'text' },
      { k: 'maxTdp', label: 'حداکثر TDP (وات)', type: 'number' }
    ],
    deco: [
      { k: 'dtype', label: 'نوع', type: 'text' }
    ],
    case: [
      { k: 'forms', label: 'مادربردهای سازگار (با ویرگول)', type: 'text' },
      { k: 'maxGpu', label: 'حداکثر طول GPU (mm)', type: 'number' }
    ],
    psu: [
      { k: 'watt', label: 'توان (وات)', type: 'number' },
      { k: 'rating', label: 'گواهی 80+', type: 'text' }
    ],
    periph: [
      { k: 'ptype', label: 'نوع', type: 'select', options: ['کیبورد', 'ماوس', 'مانیتور', 'هدست', 'وب‌کم', 'پد ماوس', 'اسپیکر'] },
      { k: 'detail', label: 'مشخصات', type: 'text' }
    ],
    net: [
      { k: 'ntype', label: 'نوع', type: 'select', options: ['مودم/روتر', 'سوییچ', 'کارت شبکه', 'اکسس‌پوینت', 'کابل شبکه', 'تقویت‌کننده'] },
      { k: 'detail', label: 'مشخصات', type: 'text' }
    ]
  };

  const ALL = 'AM4,AM5,LGA1700,LGA1851';
  const products = [
    /* ---------- CPU ---------- */
    P('c1', 'cpu', 'Ryzen 5 5600', 'AMD', 5200000, 0, 12, { socket: 'AM4', cores: 6, tdp: 65, score: 48, igpu: 'خیر' }),
    P('c2', 'cpu', 'Ryzen 7 5700X3D', 'AMD', 11000000, 8, 6, { socket: 'AM4', cores: 8, tdp: 105, score: 66, igpu: 'خیر' }),
    P('c3', 'cpu', 'Ryzen 5 7500F', 'AMD', 9500000, 0, 10, { socket: 'AM5', cores: 6, tdp: 65, score: 62, igpu: 'خیر' }),
    P('c4', 'cpu', 'Ryzen 5 9600X', 'AMD', 12500000, 5, 8, { socket: 'AM5', cores: 6, tdp: 65, score: 70, igpu: 'بله' }),
    P('c5', 'cpu', 'Ryzen 7 7800X3D', 'AMD', 24000000, 0, 5, { socket: 'AM5', cores: 8, tdp: 120, score: 90, igpu: 'بله' }),
    P('c6', 'cpu', 'Ryzen 9 9950X', 'AMD', 33000000, 10, 3, { socket: 'AM5', cores: 16, tdp: 170, score: 97, igpu: 'بله' }),
    P('c7', 'cpu', 'Core i3-12100F', 'Intel', 3800000, 0, 15, { socket: 'LGA1700', cores: 4, tdp: 58, score: 35, igpu: 'خیر' }),
    P('c8', 'cpu', 'Core i3-12100', 'Intel', 4300000, 0, 9, { socket: 'LGA1700', cores: 4, tdp: 60, score: 36, igpu: 'بله' }),
    P('c9', 'cpu', 'Core i5-13400F', 'Intel', 8000000, 0, 11, { socket: 'LGA1700', cores: 10, tdp: 65, score: 52, igpu: 'خیر' }),
    P('c10', 'cpu', 'Core i5-14600K', 'Intel', 14500000, 12, 7, { socket: 'LGA1700', cores: 14, tdp: 125, score: 73, igpu: 'بله' }),
    P('c11', 'cpu', 'Core i7-14700K', 'Intel', 20500000, 0, 6, { socket: 'LGA1700', cores: 20, tdp: 125, score: 84, igpu: 'بله' }),
    P('c12', 'cpu', 'Core i9-14900K', 'Intel', 30000000, 0, 4, { socket: 'LGA1700', cores: 24, tdp: 125, score: 95, igpu: 'بله' }),
    P('c13', 'cpu', 'Core Ultra 7 265K', 'Intel', 21000000, 7, 5, { socket: 'LGA1851', cores: 20, tdp: 125, score: 86, igpu: 'بله' }),

    /* ---------- GPU ---------- */
    P('g1', 'gpu', 'GeForce GTX 1650 4GB', 'MSI', 6500000, 0, 8, { vram: 4, tdp: 75, length: 200, score: 25 }),
    P('g2', 'gpu', 'Radeon RX 7600 8GB', 'Gigabyte', 11500000, 6, 9, { vram: 8, tdp: 165, length: 240, score: 44 }),
    P('g3', 'gpu', 'GeForce RTX 4060 8GB', 'ASUS', 14500000, 0, 12, { vram: 8, tdp: 115, length: 240, score: 50 }),
    P('g4', 'gpu', 'GeForce RTX 4060 Ti 16GB', 'MSI', 20000000, 0, 6, { vram: 16, tdp: 160, length: 250, score: 58 }),
    P('g5', 'gpu', 'Radeon RX 7800 XT 16GB', 'Sapphire', 29000000, 9, 5, { vram: 16, tdp: 263, length: 300, score: 70 }),
    P('g6', 'gpu', 'GeForce RTX 4070 Super 12GB', 'ASUS', 33000000, 0, 7, { vram: 12, tdp: 220, length: 300, score: 72 }),
    P('g7', 'gpu', 'GeForce RTX 4070 Ti Super 16GB', 'Gigabyte', 44000000, 0, 4, { vram: 16, tdp: 285, length: 320, score: 80 }),
    P('g8', 'gpu', 'Radeon RX 7900 XTX 24GB', 'Sapphire', 52000000, 5, 3, { vram: 24, tdp: 355, length: 320, score: 85 }),
    P('g9', 'gpu', 'GeForce RTX 4080 Super 16GB', 'MSI', 62000000, 0, 3, { vram: 16, tdp: 320, length: 340, score: 90 }),
    P('g10', 'gpu', 'GeForce RTX 4090 24GB', 'ASUS', 120000000, 0, 2, { vram: 24, tdp: 450, length: 350, score: 100 }),

    /* ---------- RAM ---------- */
    P('r1', 'ram', 'DDR4 8GB 3200MHz', 'Kingston', 1100000, 0, 20, { type: 'DDR4', size: 8, speed: 3200 }),
    P('r2', 'ram', 'DDR4 16GB (2x8) 3200MHz', 'Corsair', 2100000, 0, 18, { type: 'DDR4', size: 16, speed: 3200 }),
    P('r3', 'ram', 'DDR4 32GB (2x16) 3600MHz', 'G.Skill', 4200000, 5, 10, { type: 'DDR4', size: 32, speed: 3600 }),
    P('r4', 'ram', 'DDR5 16GB (2x8) 5600MHz', 'Kingston', 2700000, 0, 15, { type: 'DDR5', size: 16, speed: 5600 }),
    P('r5', 'ram', 'DDR5 32GB (2x16) 6000MHz', 'G.Skill', 5800000, 0, 12, { type: 'DDR5', size: 32, speed: 6000 }),
    P('r6', 'ram', 'DDR5 32GB (2x16) 7200MHz RGB', 'Corsair', 8000000, 10, 6, { type: 'DDR5', size: 32, speed: 7200 }),
    P('r7', 'ram', 'DDR5 64GB (2x32) 6000MHz', 'Corsair', 11500000, 0, 5, { type: 'DDR5', size: 64, speed: 6000 }),

    /* ---------- Motherboard ---------- */
    P('m1', 'mb', 'A520M', 'Gigabyte', 3300000, 0, 8, { socket: 'AM4', ramType: 'DDR4', form: 'mATX', chipset: 'A520' }),
    P('m2', 'mb', 'B550M Pro', 'MSI', 5200000, 0, 9, { socket: 'AM4', ramType: 'DDR4', form: 'mATX', chipset: 'B550' }),
    P('m3', 'mb', 'A620M', 'ASRock', 5500000, 0, 8, { socket: 'AM5', ramType: 'DDR5', form: 'mATX', chipset: 'A620' }),
    P('m4', 'mb', 'B650 Gaming Plus', 'MSI', 9000000, 5, 7, { socket: 'AM5', ramType: 'DDR5', form: 'ATX', chipset: 'B650' }),
    P('m5', 'mb', 'B650I Aorus (ITX)', 'Gigabyte', 12000000, 0, 3, { socket: 'AM5', ramType: 'DDR5', form: 'ITX', chipset: 'B650' }),
    P('m6', 'mb', 'X670E Hero', 'ASUS', 17000000, 0, 3, { socket: 'AM5', ramType: 'DDR5', form: 'ATX', chipset: 'X670E' }),
    P('m7', 'mb', 'H610M', 'ASUS', 3200000, 0, 10, { socket: 'LGA1700', ramType: 'DDR4', form: 'mATX', chipset: 'H610' }),
    P('m8', 'mb', 'B760M DDR4', 'MSI', 5800000, 0, 8, { socket: 'LGA1700', ramType: 'DDR4', form: 'mATX', chipset: 'B760' }),
    P('m9', 'mb', 'B760M DDR5', 'Gigabyte', 7200000, 0, 7, { socket: 'LGA1700', ramType: 'DDR5', form: 'mATX', chipset: 'B760' }),
    P('m10', 'mb', 'Z790 Aorus Elite', 'Gigabyte', 14500000, 8, 5, { socket: 'LGA1700', ramType: 'DDR5', form: 'ATX', chipset: 'Z790' }),
    P('m11', 'mb', 'Z890 Tomahawk', 'MSI', 16500000, 0, 4, { socket: 'LGA1851', ramType: 'DDR5', form: 'ATX', chipset: 'Z890' }),

    /* ---------- Storage ---------- */
    P('s1', 'storage', 'SSD NVMe 500GB', 'WD', 1800000, 0, 20, { kind: 'NVMe SSD', size: 500 }),
    P('s2', 'storage', 'SSD NVMe 1TB', 'Samsung', 3200000, 5, 18, { kind: 'NVMe SSD', size: 1000 }),
    P('s3', 'storage', 'SSD NVMe 2TB', 'Samsung', 6500000, 0, 9, { kind: 'NVMe SSD', size: 2000 }),
    P('s4', 'storage', 'SSD SATA 480GB', 'Kingston', 1400000, 0, 14, { kind: 'SATA SSD', size: 480 }),
    P('s5', 'storage', 'HDD 2TB 7200rpm', 'Seagate', 3000000, 0, 10, { kind: 'HDD', size: 2000 }),
    P('s6', 'storage', 'SSD اکسترنال 1TB', 'Samsung', 4500000, 10, 8, { kind: 'SSD اکسترنال', size: 1000 }),
    P('s7', 'storage', 'هارد اکسترنال 2TB', 'WD', 3800000, 0, 11, { kind: 'HDD اکسترنال', size: 2000 }),

    /* ---------- Cooler ---------- */
    P('k1', 'cooler', 'AG400 (هوایی)', 'DeepCool', 1100000, 0, 15, { ctype: 'هوایی', sockets: ALL, maxTdp: 220 }),
    P('k2', 'cooler', 'Hyper 212', 'Cooler Master', 1300000, 0, 12, { ctype: 'هوایی', sockets: ALL, maxTdp: 150 }),
    P('k3', 'cooler', 'Peerless Assassin 120', 'Thermalright', 1900000, 0, 9, { ctype: 'هوایی', sockets: ALL, maxTdp: 245 }),
    P('k4', 'cooler', 'NH-D15', 'Noctua', 4800000, 0, 5, { ctype: 'هوایی', sockets: ALL, maxTdp: 260 }),
    P('k5', 'cooler', 'LS520 AIO 240mm', 'DeepCool', 5500000, 8, 6, { ctype: 'مایع', sockets: ALL, maxTdp: 300 }),
    P('k6', 'cooler', 'iCUE H150i AIO 360mm', 'Corsair', 9000000, 0, 4, { ctype: 'مایع', sockets: ALL, maxTdp: 350 }),

    /* ---------- Decorative ---------- */
    P('d1', 'deco', 'پک ۳ فن ARGB', 'Lian Li', 1400000, 0, 12, { dtype: 'فن RGB' }),
    P('d2', 'deco', 'نوار LED آدرس‌پذیر', 'Corsair', 600000, 0, 20, { dtype: 'نوار LED' }),
    P('d3', 'deco', 'نگهدارنده کارت گرافیک', 'Cooler Master', 450000, 0, 15, { dtype: 'براکت GPU' }),
    P('d4', 'deco', 'کیت نصب عمودی GPU', 'Lian Li', 1800000, 5, 6, { dtype: 'کیت Vertical' }),
    P('d5', 'deco', 'کابل‌های سفارشی Sleeved', 'CableMod', 900000, 0, 10, { dtype: 'کابل سفارشی' }),

    /* ---------- Case ---------- */
    P('x1', 'case', 'MasterBox Q300L', 'Cooler Master', 2300000, 0, 10, { forms: 'mATX,ITX', maxGpu: 360 }),
    P('x2', 'case', 'H510', 'NZXT', 4200000, 0, 8, { forms: 'ATX,mATX,ITX', maxGpu: 381 }),
    P('x3', 'case', '4000D Airflow', 'Corsair', 5800000, 6, 9, { forms: 'ATX,mATX,ITX', maxGpu: 360 }),
    P('x4', 'case', 'Air 903 Max', 'Montech', 5000000, 0, 7, { forms: 'ATX,mATX,ITX', maxGpu: 400 }),
    P('x5', 'case', 'Lancool 216', 'Lian Li', 6800000, 0, 6, { forms: 'ATX,mATX,ITX', maxGpu: 392 }),
    P('x6', 'case', 'NR200P (کوچک)', 'Cooler Master', 5500000, 0, 5, { forms: 'ITX', maxGpu: 330 }),
    P('x7', 'case', 'North', 'Fractal', 9500000, 0, 4, { forms: 'ATX,mATX,ITX', maxGpu: 355 }),

    /* ---------- PSU ---------- */
    P('p1', 'psu', 'پاور 450W', 'Green', 1400000, 0, 15, { watt: 450, rating: '80+ White' }),
    P('p2', 'psu', 'پاور 550W', 'Corsair', 1900000, 0, 12, { watt: 550, rating: '80+ Bronze' }),
    P('p3', 'psu', 'پاور 650W', 'Cooler Master', 2600000, 0, 12, { watt: 650, rating: '80+ Bronze' }),
    P('p4', 'psu', 'پاور 750W', 'MSI', 3800000, 0, 10, { watt: 750, rating: '80+ Gold' }),
    P('p5', 'psu', 'پاور 850W', 'Corsair', 5200000, 5, 8, { watt: 850, rating: '80+ Gold' }),
    P('p6', 'psu', 'پاور 1000W', 'Seasonic', 8000000, 0, 5, { watt: 1000, rating: '80+ Gold' }),
    P('p7', 'psu', 'پاور 1200W', 'ASUS', 11500000, 0, 3, { watt: 1200, rating: '80+ Platinum' }),

    /* ---------- Peripherals ---------- */
    P('j1', 'periph', 'کیبورد مکانیکال K70', 'Corsair', 4800000, 10, 10, { ptype: 'کیبورد', detail: 'سوییچ Red، RGB' }),
    P('j2', 'periph', 'کیبورد ۷۵٪ Keychron', 'Keychron', 5600000, 0, 7, { ptype: 'کیبورد', detail: 'بی‌سیم، Hot-swap' }),
    P('j3', 'periph', 'ماوس G502', 'Logitech', 2200000, 0, 14, { ptype: 'ماوس', detail: '25600 DPI، سیم‌دار' }),
    P('j4', 'periph', 'ماوس سبک Viper', 'Razer', 3900000, 8, 9, { ptype: 'ماوس', detail: '58 گرم، بی‌سیم' }),
    P('j5', 'periph', 'مانیتور 27 اینچ 165Hz', 'LG', 14500000, 0, 6, { ptype: 'مانیتور', detail: 'QHD، IPS، 1ms' }),
    P('j6', 'periph', 'مانیتور 24 اینچ 144Hz', 'AOC', 7800000, 5, 9, { ptype: 'مانیتور', detail: 'FHD، VA' }),
    P('j7', 'periph', 'مانیتور 34 اینچ اولتراواید', 'Samsung', 26000000, 0, 3, { ptype: 'مانیتور', detail: 'WQHD، 165Hz، منحنی' }),
    P('j8', 'periph', 'هدست HyperX Cloud II', 'HyperX', 3300000, 0, 11, { ptype: 'هدست', detail: '7.1 مجازی' }),
    P('j9', 'periph', 'وب‌کم C920', 'Logitech', 2400000, 0, 8, { ptype: 'وب‌کم', detail: 'Full HD 1080p' }),
    P('j10', 'periph', 'پد ماوس بزرگ', 'SteelSeries', 700000, 0, 25, { ptype: 'پد ماوس', detail: '900×400mm' }),

    /* ---------- Network ---------- */
    P('n1', 'net', 'روتر AX3000 Wi-Fi 6', 'TP-Link', 4200000, 0, 12, { ntype: 'مودم/روتر', detail: 'Wi-Fi 6، دو باند' }),
    P('n2', 'net', 'روتر Wi-Fi 7 BE9300', 'ASUS', 14500000, 6, 4, { ntype: 'مودم/روتر', detail: 'Wi-Fi 7، سه باند' }),
    P('n3', 'net', 'سوییچ 8 پورت گیگابیت', 'TP-Link', 1100000, 0, 20, { ntype: 'سوییچ', detail: '8×1Gbps' }),
    P('n4', 'net', 'سوییچ 16 پورت مدیریتی', 'D-Link', 4800000, 0, 6, { ntype: 'سوییچ', detail: '16×1Gbps، Layer2' }),
    P('n5', 'net', 'کارت شبکه PCIe Wi-Fi 6E', 'Gigabyte', 1500000, 0, 14, { ntype: 'کارت شبکه', detail: 'Wi-Fi 6E + بلوتوث' }),
    P('n6', 'net', 'کارت شبکه 2.5G', 'TP-Link', 900000, 10, 10, { ntype: 'کارت شبکه', detail: 'PCIe، 2.5Gbps' }),
    P('n7', 'net', 'اکسس‌پوینت سقفی', 'Ubiquiti', 6200000, 0, 5, { ntype: 'اکسس‌پوینت', detail: 'Wi-Fi 6، PoE' }),
    P('n8', 'net', 'کابل شبکه Cat6 (۲۰ متر)', 'Dnet', 350000, 0, 40, { ntype: 'کابل شبکه', detail: 'Cat6، شیلدار' }),
    P('n9', 'net', 'رپیتر Mesh', 'Xiaomi', 1800000, 0, 9, { ntype: 'تقویت‌کننده', detail: 'AX1500' })
  ];

  window.ERFAN_DEFAULTS = {
    version: 1,
    settings: { storeName: 'Erfan.', assemblyFee: 1500000, globalSale: 0, phone: '021-00000000' },
    categories, specSchema, products,
    coupons: [
      { code: 'ERFAN10', percent: 10, active: true },
      { code: 'WELCOME5', percent: 5, active: true }
    ],
    orders: []
  };
})();
