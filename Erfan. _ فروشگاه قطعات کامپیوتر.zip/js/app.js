/* =====================================================
   Erfan. — منطق اصلی سایت: روتر، لیست کالا، سبد خرید، سفارش
   (اسمبل هوشمند در assembly.js)
   ===================================================== */
const App = (() => {
  const { esc, toman, fmt, finalPrice, discountPct } = Store;
  const $ = (s, r = document) => r.querySelector(s);
  const app = $('#app');
  const routes = {};
  const CK = 'erfan_cart', KK = 'erfan_coupon';
  let cartMem = [], couponMem = '';

  /* ---------- Toast & Modal ---------- */
  function toast(msg, err) {
    const t = document.createElement('div');
    t.className = 'toast' + (err ? ' err' : '');
    t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }
  function modal(html) {
    const o = document.createElement('div');
    o.className = 'overlay';
    o.innerHTML = `<div class="modal"><button class="close" aria-label="بستن">×</button>${html}</div>`;
    o.addEventListener('click', (e) => { if (e.target === o || e.target.classList.contains('close')) o.remove(); });
    document.body.appendChild(o);
    return o;
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.overlay').forEach((o) => o.remove()); });

  /* ---------- Cart (localStorage) ---------- */
  const Cart = {
    get() { try { return JSON.parse(localStorage.getItem(CK)) || []; } catch (e) { return cartMem; } },
    set(a) { cartMem = a; try { localStorage.setItem(CK, JSON.stringify(a)); } catch (e) {} badge(); },
    add(id, qty = 1) {
      const a = this.get();
      const it = a.find((x) => x.id === id);
      if (id === 'ASM_FEE') { if (!it) a.push({ id, qty: 1 }); this.set(a); return true; }
      const p = Store.product(id);
      if (!p) return false;
      const have = it ? it.qty : 0;
      if (have + qty > p.stock) { toast('موجودی این کالا کافی نیست', true); return false; }
      if (it) it.qty += qty; else a.push({ id, qty });
      this.set(a);
      return true;
    },
    clear() { this.set([]); },
    count() { return this.get().reduce((s, x) => s + (x.id === 'ASM_FEE' ? 0 : x.qty), 0); }
  };
  function badge() { const el = $('#cartCount'); if (el) el.textContent = fmt(Cart.count()); }
  const getCoupon = () => { try { return localStorage.getItem(KK) || ''; } catch (e) { return couponMem; } };
  const setCoupon = (c) => { couponMem = c; try { localStorage.setItem(KK, c); } catch (e) {} };

  /* ---------- Helpers ---------- */
  function summary(p) {
    const s = p.spec || {};
    switch (p.cat) {
      case 'cpu': return `${s.socket} • ${s.cores} هسته • ${s.tdp}W`;
      case 'gpu': return `${s.vram}GB • ${s.tdp}W • ${s.length}mm`;
      case 'ram': return `${s.type} • ${s.size}GB • ${s.speed}MHz`;
      case 'mb': return `${s.socket} • ${s.ramType} • ${s.form}`;
      case 'storage': return `${s.kind} • ${s.size >= 1000 ? s.size / 1000 + 'TB' : s.size + 'GB'}`;
      case 'cooler': return `${s.ctype} • تا ${s.maxTdp}W`;
      case 'deco': return s.dtype || '';
      case 'case': return `${s.forms} • GPU تا ${s.maxGpu}mm`;
      case 'psu': return `${s.watt}W • ${s.rating}`;
      case 'periph': return `${s.ptype} • ${s.detail}`;
      case 'net': return `${s.ntype} • ${s.detail}`;
      default: return '';
    }
  }

  function priceHtml(p) {
    const d = discountPct(p);
    return `<div class="price-box">${d ? `<div class="old">${toman(p.price)}</div>` : ''}<div class="price">${fmt(finalPrice(p))} <small>تومان</small></div></div>`;
  }

  function card(p) {
    const c = Store.cat(p.cat);
    const d = discountPct(p);
    const out = p.stock <= 0;
    return `<article class="card">
      <div class="thumb">${p.img ? `<img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy">` : c.icon}
        ${out ? '<span class="badge out">ناموجود</span>' : d ? `<span class="badge">٪${fmt(d)} تخفیف</span>` : ''}</div>
      <div class="body">
        <div class="pbrand">${esc(p.brand)}</div>
        <div class="pname">${esc(p.name)}</div>
        <div class="pspec">${esc(summary(p))}</div>
        ${priceHtml(p)}
        <div class="actions">
          <button class="btn btn-primary btn-sm" data-add="${p.id}" ${out ? 'disabled' : ''}>افزودن به سبد</button>
          <button class="btn btn-ghost btn-sm" data-detail="${p.id}">جزئیات</button>
        </div>
      </div></article>`;
  }

  function detailModal(id) {
    const p = Store.product(id);
    if (!p) return;
    const schema = Store.db.specSchema[p.cat] || [];
    const rows = schema.map((f) => `<tr><td>${esc(f.label)}</td><td dir="auto">${esc(p.spec[f.k] ?? '—')}</td></tr>`).join('');
    modal(`<h3 dir="auto">${esc(p.name)}</h3>
      <p class="muted" style="margin-bottom:12px">${esc(Store.cat(p.cat).name)} • برند ${esc(p.brand)} • موجودی: ${fmt(p.stock)}</p>
      <table class="spec-table"><tbody>${rows}</tbody></table>
      <div class="row" style="justify-content:space-between;margin-top:18px">${priceHtml(p)}
      <button class="btn btn-primary" data-add="${p.id}" ${p.stock <= 0 ? 'disabled' : ''}>افزودن به سبد</button></div>`);
  }

  /* ---------- Listing با فیلتر و مرتب‌سازی ---------- */
  const listState = {};
  function listing(cfg) {
    const db = Store.db;
    const st = (listState[cfg.key] = listState[cfg.key] || { q: '', brand: '', sort: 'default', max: '', stock: false });
    let base = db.products.filter((p) => cfg.cats.includes(p.cat));
    if (cfg.discounted) base = base.filter((p) => discountPct(p) > 0);
    const brands = [...new Set(base.map((p) => p.brand))].sort();
    const tabs = [{ id: 'all', label: 'همه' }, ...cfg.tabs];
    const sel = cfg.tab || 'all';
    const tabHtml = tabs.map((t) => `<a class="tab ${t.id === sel ? 'active' : ''}" href="${cfg.base}${t.id === 'all' ? '' : '/' + encodeURIComponent(t.id)}">${esc(t.label)}</a>`).join('');

    app.innerHTML = `
      <div class="section-title"><h2>${cfg.title}</h2><span class="kicker">${cfg.kicker || ''}</span></div>
      ${cfg.intro || ''}
      <div class="tabs">${tabHtml}</div>
      <div class="filters">
        <div><label>جستجو</label><input id="fq" placeholder="نام یا برند…" value="${esc(st.q)}"></div>
        <div><label>برند</label><select id="fb"><option value="">همه برندها</option>${brands.map((b) => `<option ${st.brand === b ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select></div>
        <div><label>مرتب‌سازی</label><select id="fs">
          ${[['default', 'پیش‌فرض'], ['asc', 'ارزان‌ترین'], ['desc', 'گران‌ترین'], ['disc', 'بیشترین تخفیف']].map(([v, l]) => `<option value="${v}" ${st.sort === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
        <div><label>سقف قیمت (تومان)</label><input id="fm" type="number" min="0" placeholder="مثلاً 20000000" value="${esc(st.max)}"></div>
        <label style="display:flex;gap:6px;align-items:center;margin:0 0 10px"><input id="fi" type="checkbox" ${st.stock ? 'checked' : ''}> فقط موجود</label>
      </div>
      <div id="results"></div>`;

    function paint() {
      let items = base.filter((p) => sel === 'all' || cfg.tabFn(p) === sel);
      const q = st.q.trim().toLowerCase();
      if (q) items = items.filter((p) => (p.name + ' ' + p.brand).toLowerCase().includes(q));
      if (st.brand) items = items.filter((p) => p.brand === st.brand);
      if (st.max) items = items.filter((p) => finalPrice(p) <= Number(st.max));
      if (st.stock) items = items.filter((p) => p.stock > 0);
      if (st.sort === 'asc') items.sort((a, b) => finalPrice(a) - finalPrice(b));
      if (st.sort === 'desc') items.sort((a, b) => finalPrice(b) - finalPrice(a));
      if (st.sort === 'disc') items.sort((a, b) => discountPct(b) - discountPct(a));
      $('#results').innerHTML = items.length
        ? `<p class="muted" style="margin-bottom:10px">${fmt(items.length)} کالا</p><div class="grid cards">${items.map(card).join('')}</div>`
        : '<div class="empty">کالایی با این فیلترها پیدا نشد.</div>';
    }
    const bind = (id, key, ev = 'input', get = (e) => e.target.value) => $(id).addEventListener(ev, (e) => { st[key] = get(e); paint(); });
    bind('#fq', 'q'); bind('#fb', 'brand', 'change'); bind('#fs', 'sort', 'change'); bind('#fm', 'max');
    bind('#fi', 'stock', 'change', (e) => e.target.checked);
    paint();
  }

  /* ---------- Routes ---------- */
  routes[''] = () => {
    const db = Store.db;
    const tiles = db.categories.map((c) => {
      const href = c.group === 'parts' ? '#/parts/' + c.id : '#/' + c.group;
      const n = db.products.filter((p) => p.cat === c.id).length;
      return `<a class="tile" href="${href}"><span class="ic">${c.icon}</span><b>${c.name}</b><small>${fmt(n)} کالا</small></a>`;
    }).join('');
    const hot = db.products.filter((p) => discountPct(p) > 0 && p.stock > 0).sort((a, b) => discountPct(b) - discountPct(a)).slice(0, 4);
    app.innerHTML = `
      <section class="hero">
        <div class="glyph">🖥️</div>
        <h1>سیستم رویایی‌ات را <b>با Erfan.</b> بساز</h1>
        <div class="tag">هر قطعه، دقیقاً سر جای خودش</div>
        <p>از پردازنده و کارت گرافیک تا تجهیزات شبکه؛ یا فقط بودجه‌ات را بگو تا «اسمبل هوشمند» یک سیستم کاملاً سازگار بچیند و قیمت نهایی را همان لحظه ببینی.</p>
        <div class="row"><a class="btn btn-primary" href="#/assembly">⚡ اسمبل هوشمند</a><a class="btn btn-ghost" href="#/parts">مشاهده قطعات</a></div>
      </section>
      <div class="section-title"><h2>دسته‌بندی‌ها</h2><span class="kicker">هرچه لازم داری</span></div>
      <div class="grid cat-tiles">${tiles}<a class="tile" href="#/assembly"><span class="ic">🤖</span><b>اسمبل هوشمند</b><small>سیستم کامل با بودجه تو</small></a></div>
      <div class="section-title"><h2>داغ‌ترین تخفیف‌ها</h2><a class="kicker" href="#/discounts">همه تخفیف‌ها ←</a></div>
      <div class="grid cards">${hot.map(card).join('') || '<div class="empty">فعلاً تخفیفی نیست.</div>'}</div>`;
  };

  routes.parts = (arg) => {
    const cats = Store.db.categories.filter((c) => c.group === 'parts');
    listing({ key: 'parts', title: 'قطعات کامپیوتر', kicker: 'CPU تا کیس', cats: cats.map((c) => c.id), base: '#/parts', tab: arg,
      tabs: cats.map((c) => ({ id: c.id, label: c.icon + ' ' + c.name })), tabFn: (p) => p.cat });
  };
  routes.periph = (arg) => listing({ key: 'periph', title: 'تجهیزات جانبی', kicker: 'کیبورد، ماوس، مانیتور و…', cats: ['periph'], base: '#/periph', tab: arg,
    tabs: Store.db.specSchema.periph[0].options.map((o) => ({ id: o, label: o })), tabFn: (p) => p.spec.ptype });
  routes.net = (arg) => listing({ key: 'net', title: 'تجهیزات شبکه', kicker: 'اتصال پایدار', cats: ['net'], base: '#/net', tab: arg,
    tabs: Store.db.specSchema.net[0].options.map((o) => ({ id: o, label: o })), tabFn: (p) => p.spec.ntype });
  routes.discounts = (arg) => {
    const db = Store.db;
    const g = Number(db.settings.globalSale) || 0;
    const codes = db.coupons.filter((c) => c.active).map((c) => `<span class="tab active" style="cursor:default">${esc(c.code)} ← ٪${fmt(c.percent)}</span>`).join(' ');
    const intro = `${g ? `<div class="notice" style="margin-bottom:14px">🎉 جشنواره فعال: روی همه کالاها حداقل ٪${fmt(g)} تخفیف</div>` : ''}
      <div class="panel" style="margin-bottom:18px"><span class="kicker">کد تخفیف</span> <span class="muted">— در سبد خرید وارد کنید:</span><div class="row" style="margin-top:8px">${codes || '<span class="muted">فعلاً کدی فعال نیست</span>'}</div></div>`;
    listing({ key: 'disc', title: 'تخفیف‌ها', kicker: 'فرصت‌های محدود', cats: db.categories.map((c) => c.id), discounted: true, intro, base: '#/discounts', tab: arg,
      tabs: db.categories.map((c) => ({ id: c.id, label: c.icon + ' ' + c.name })), tabFn: (p) => p.cat });
  };

  /* ---------- Cart view ---------- */
  function resolve(it) {
    const db = Store.db;
    if (it.id === 'ASM_FEE') return { id: it.id, name: 'هزینه اسمبل، تست و نصب سیستم', unit: Number(db.settings.assemblyFee) || 0, qty: 1, icon: '🛠️', fee: true };
    const p = Store.product(it.id);
    if (!p) return null;
    return { id: p.id, name: p.name, unit: finalPrice(p), qty: Math.min(it.qty, Math.max(p.stock, 0)), icon: Store.cat(p.cat).icon, stock: p.stock };
  }
  function cartTotals(lines) {
    const sub = lines.reduce((s, l) => s + l.unit * l.qty, 0);
    const base = lines.filter((l) => !l.fee).reduce((s, l) => s + l.unit * l.qty, 0);
    const cp = Store.db.coupons.find((c) => c.active && c.code.toUpperCase() === getCoupon().toUpperCase());
    const off = cp ? Math.round((base * cp.percent) / 100 / 1000) * 1000 : 0;
    return { sub, off, cp, total: sub - off };
  }

  routes.cart = () => {
    const lines = Cart.get().map(resolve).filter((l) => l && l.qty > 0);
    if (!lines.length) { app.innerHTML = '<div class="empty"><h2>سبد خرید خالی است</h2><p style="margin:10px 0 18px">برای شروع، سیستم خودت را بساز!</p><a class="btn btn-primary" href="#/assembly">اسمبل هوشمند</a></div>'; return; }
    const t = cartTotals(lines);
    app.innerHTML = `<div class="section-title"><h2>سبد خرید</h2><span class="kicker">تکمیل سفارش</span></div>
      <div class="cart-layout">
        <div class="panel table-wrap"><table>
          <thead><tr><th></th><th>کالا</th><th>قیمت واحد</th><th>تعداد</th><th>جمع</th><th></th></tr></thead>
          <tbody>${lines.map((l) => `<tr><td style="font-size:1.6rem">${l.icon}</td><td dir="auto">${esc(l.name)}</td><td>${fmt(l.unit)}</td>
            <td>${l.fee ? '۱' : `<span class="qty"><button data-q="${l.id}" data-d="-1">−</button>${fmt(l.qty)}<button data-q="${l.id}" data-d="1">+</button></span>`}</td>
            <td><b>${fmt(l.unit * l.qty)}</b></td><td><button class="btn btn-danger btn-sm" data-rm="${l.id}">حذف</button></td></tr>`).join('')}</tbody></table></div>
        <aside class="panel">
          <h3>خلاصه سفارش</h3>
          <div class="field" style="margin-top:12px"><label>کد تخفیف</label><div class="row" style="flex-wrap:nowrap"><input id="cpn" value="${esc(getCoupon())}" placeholder="مثلاً ERFAN10"><button class="btn btn-ghost" id="cpnBtn">اعمال</button></div>
            ${getCoupon() ? (t.cp ? `<small class="good">کد ${esc(t.cp.code)} (٪${fmt(t.cp.percent)}) اعمال شد</small>` : '<small class="bad">کد نامعتبر است</small>') : ''}</div>
          <div class="totals">
            <div class="line"><span>جمع کالاها</span><span>${toman(t.sub)}</span></div>
            <div class="line"><span>تخفیف کد</span><span class="good">− ${toman(t.off)}</span></div>
            <div class="line grand"><span>مبلغ نهایی</span><span>${toman(t.total)}</span></div>
          </div>
          <hr style="border:0;border-top:1px solid var(--border);margin:18px 0">
          <form id="checkout">
            <div class="field"><label>نام و نام خانوادگی</label><input name="name" required></div>
            <div class="field"><label>شماره تماس</label><input name="phone" required inputmode="tel" pattern="[0-9۰-۹]{10,11}" title="شماره ۱۰ یا ۱۱ رقمی"></div>
            <div class="field"><label>آدرس</label><textarea name="address" rows="2" required></textarea></div>
            <button class="btn btn-primary" style="width:100%">ثبت سفارش</button>
          </form>
        </aside></div>`;
    $('#cpnBtn').onclick = () => { setCoupon($('#cpn').value.trim()); routes.cart(); };
    $('#checkout').onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target);
      const db = Store.db;
      const items = lines.map((l) => ({ id: l.id, name: l.name, qty: l.qty, unit: l.unit }));
      /* بررسی مجدد موجودی و کسر از انبار */
      for (const l of lines) if (!l.fee && Store.product(l.id).stock < l.qty) return toast('موجودی «' + l.name + '» کافی نیست', true);
      lines.forEach((l) => { if (!l.fee) Store.product(l.id).stock -= l.qty; });
      const order = { id: 'ORD-' + Date.now().toString(36).toUpperCase(), date: new Date().toISOString(),
        customer: { name: f.get('name'), phone: f.get('phone'), address: f.get('address') },
        items, subtotal: t.sub, coupon: t.cp ? t.cp.code : '', couponDiscount: t.off, total: t.total, status: 'جدید' };
      db.orders.unshift(order);
      Store.save();
      Cart.clear(); setCoupon('');
      app.innerHTML = `<div class="empty"><div style="font-size:4rem">✅</div><h2>سفارش ثبت شد</h2>
        <p style="margin:10px 0">کد پیگیری: <b dir="ltr">${order.id}</b></p><p>مبلغ نهایی: <b class="good">${toman(order.total)}</b></p>
        <a class="btn btn-primary" style="margin-top:18px" href="#/">بازگشت به فروشگاه</a></div>`;
    };
  };

  /* ---------- Router ---------- */
  function route() {
    Store.load(); /* همگام با تغییرات پنل ادمین */
    const h = location.hash.replace(/^#\/?/, '');
    const [name, arg] = h.split('/');
    const fn = routes[name || ''] || routes[''];
    fn(arg ? decodeURIComponent(arg) : undefined);
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.r === (name || '')));
    $('#footPhone').textContent = 'تلفن پشتیبانی: ' + Store.db.settings.phone;
    badge();
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);
  window.addEventListener('DOMContentLoaded', route);

  /* ---------- Global events ---------- */
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-add],[data-detail],[data-q],[data-rm]');
    if (!t) return;
    if (t.dataset.add) { if (Cart.add(t.dataset.add)) toast('به سبد خرید اضافه شد ✔'); }
    else if (t.dataset.detail) detailModal(t.dataset.detail);
    else if (t.dataset.q) {
      const a = Cart.get(); const it = a.find((x) => x.id === t.dataset.q); const p = Store.product(t.dataset.q);
      if (!it) return;
      const n = it.qty + Number(t.dataset.d);
      if (n < 1) return;
      if (p && n > p.stock) return toast('موجودی کافی نیست', true);
      it.qty = n; Cart.set(a); routes.cart();
    } else if (t.dataset.rm) { Cart.set(Cart.get().filter((x) => x.id !== t.dataset.rm)); routes.cart(); }
  });

  return { routes, Cart, toast, modal, summary, card, route };
})();
