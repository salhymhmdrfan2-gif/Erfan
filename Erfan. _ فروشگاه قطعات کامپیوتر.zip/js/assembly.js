/* =====================================================
   Erfan. — اسمبل هوشمند
   ورودی: بودجه + هدف استفاده (+ ترجیحات)
   خروجی: سیستم کامل سازگار + قیمت نهایی (با تخفیف‌ها + هزینه اسمبل)
   ===================================================== */
(() => {
  const { esc, toman, fmt, finalPrice: fp } = Store;
  const $ = (s) => document.querySelector(s);
  const app = $('#app');

  /* وزن اهمیت هر قطعه برای هر هدف + حداقل رم */
  const PURPOSES = {
    gaming: { label: 'گیمینگ', c: 0.9, g: 1.8, r: 0.25, s: 0.15, minRam: 16 },
    work:   { label: 'کاری و اداری', c: 1.5, g: 0.15, r: 0.5, s: 0.3, minRam: 16 },
    render: { label: 'طراحی، رندر و برنامه‌نویسی', c: 1.4, g: 1.2, r: 0.6, s: 0.25, minRam: 32 },
    budget: { label: 'اقتصادی (کمترین هزینه)', c: 1, g: 1, r: 0.2, s: 0.1, minRam: 16 }
  };
  const ORDER = ['cpu', 'gpu', 'mb', 'ram', 'storage', 'cooler', 'case', 'psu', 'deco'];

  /* ---------- توابع سازگاری ---------- */
  const list = (c) => Store.db.products.filter((p) => p.cat === c && p.stock > 0);
  const internal = (p) => !/اکسترنال/.test(p.spec.kind);
  const csv = (s) => String(s || '').split(',').map((x) => x.trim());
  const needWatt = (cpu, gpu) => Math.ceil(((Number(cpu.spec.tdp) + (gpu ? Number(gpu.spec.tdp) : 0) + 100) * 1.3) / 50) * 50;
  const coolOk = (k, cpu) => csv(k.spec.sockets).includes(cpu.spec.socket) && Number(k.spec.maxTdp) >= Number(cpu.spec.tdp);
  const caseOk = (c, mb, gpu) => csv(c.spec.forms).includes(mb.spec.form) && (!gpu || Number(c.spec.maxGpu) >= Number(gpu.spec.length));
  const sum = (b) => Object.values(b).filter(Boolean).reduce((s, p) => s + fp(p), 0);
  const cheapest = (arr) => arr.reduce((a, b) => (!a || fp(b) < fp(a) ? b : a), null);

  /* ---------- موتور انتخاب خودکار ---------- */
  function autoBuild(o) {
    const W = PURPOSES[o.purpose];
    const fee = Number(Store.db.settings.assemblyFee) || 0;
    const avail = o.budget - fee;
    const L = {};
    ORDER.forEach((c) => (L[c] = list(c)));
    L.storage = L.storage.filter(internal);
    const gpus = L.gpu.slice();
    if (o.purpose === 'work') gpus.push(null); /* برای کار اداری گرافیک داخلی کافی است */

    let best = null, bestScore = -Infinity, minNeeded = Infinity;
    for (const cpu of L.cpu) {
      if (o.brand !== 'any' && cpu.brand !== o.brand) continue;
      for (const gpu of gpus) {
        if (!gpu && cpu.spec.igpu !== 'بله') continue;
        for (const mb of L.mb) {
          if (mb.spec.socket !== cpu.spec.socket) continue;
          if (o.size === 'ITX' && mb.spec.form !== 'ITX') continue;
          if (o.size === 'compact' && mb.spec.form === 'ATX') continue;
          const need = needWatt(cpu, gpu);
          const ramO = L.ram.filter((r) => r.spec.type === mb.spec.ramType && r.spec.size >= W.minRam);
          const stO = L.storage.filter((s) => s.spec.size >= 500 && s.spec.kind !== 'HDD');
          const coO = L.cooler.filter((k) => coolOk(k, cpu));
          const caO = L.case.filter((c) => caseOk(c, mb, gpu));
          const psO = L.psu.filter((p) => p.spec.watt >= need);
          if (!ramO.length || !stO.length || !coO.length || !caO.length || !psO.length) continue;

          const b = { cpu, gpu, mb, ram: cheapest(ramO), storage: cheapest(stO), cooler: cheapest(coO), case: cheapest(caO), psu: cheapest(psO), deco: null };
          minNeeded = Math.min(minNeeded, sum(b) + fee);
          if (sum(b) > avail) continue;

          /* هزینه باقی‌مانده را به ترتیب اولویت صرف ارتقای رم، حافظه، پاور، خنک‌کننده و کیس می‌کنیم */
          let rem = avail - sum(b);
          const up = (key, opts, rank, cap) => {
            const cur = b[key];
            const room = fp(cur) + rem * cap;
            const c = opts.filter((x) => fp(x) <= room).sort((x, y) => rank(y) - rank(x) || fp(x) - fp(y))[0];
            if (c) { rem -= fp(c) - fp(cur); b[key] = c; }
          };
          const mbO = L.mb.filter((m) => m.spec.socket === mb.spec.socket && m.spec.ramType === mb.spec.ramType && m.spec.form === mb.spec.form);
          up('mb', mbO, (m) => fp(m), 0.25);
          up('ram', ramO, (r) => r.spec.size, 0.5);
          up('storage', stO, (s) => s.spec.size + (s.spec.kind === 'NVMe SSD' ? 100 : 0), 0.5);
          up('psu', psO, (p) => p.spec.watt, 0.25);
          up('cooler', coO, (k) => k.spec.maxTdp, 0.4);
          up('case', caO, (c) => fp(c), 0.5);
          if (o.deco) {
            const d = L.deco.filter((x) => fp(x) <= rem * 0.5).sort((x, y) => fp(y) - fp(x))[0];
            if (d) b.deco = d;
          }
          const score = W.c * cpu.spec.score + W.g * (gpu ? gpu.spec.score : 8) +
            W.r * 100 * Math.min(b.ram.spec.size, 64) / 64 + W.s * 100 * Math.min(b.storage.spec.size, 2000) / 2000 +
            (sum(b) / avail) * 3 - (o.purpose === 'budget' ? sum(b) / avail * 120 : 0);
          if (score > bestScore) { bestScore = score; best = b; }
        }
      }
    }
    return { build: best, minNeeded: isFinite(minNeeded) ? minNeeded : null };
  }

  /* ---------- گزینه‌های جایگزین برای هر ردیف (فقط سازگار) ---------- */
  function altsFor(key, b) {
    switch (key) {
      case 'cpu': return list('cpu').filter((c) => c.spec.socket === b.mb.spec.socket && (b.gpu || c.spec.igpu === 'بله'));
      case 'gpu': return list('gpu');
      case 'mb': return list('mb').filter((m) => m.spec.socket === b.cpu.spec.socket && m.spec.ramType === b.ram.spec.type);
      case 'ram': return list('ram').filter((r) => r.spec.type === b.mb.spec.ramType);
      case 'storage': return list('storage').filter(internal);
      case 'cooler': return list('cooler').filter((k) => csv(k.spec.sockets).includes(b.cpu.spec.socket));
      case 'case': return list('case').filter((c) => csv(c.spec.forms).includes(b.mb.spec.form));
      default: return list(key);
    }
  }
  const optional = (key, b) => key === 'deco' || (key === 'gpu' && b.cpu.spec.igpu === 'بله');

  function checks(b) {
    const need = needWatt(b.cpu, b.gpu);
    return [
      [b.cpu.spec.socket === b.mb.spec.socket, `سوکت پردازنده و مادربرد یکسان است (${b.cpu.spec.socket})`, `ناسازگاری سوکت: CPU ${b.cpu.spec.socket} ≠ مادربرد ${b.mb.spec.socket}`],
      [b.ram.spec.type === b.mb.spec.ramType, `رم ${b.ram.spec.type} با مادربرد سازگار است`, `ناسازگاری رم: ${b.ram.spec.type} روی مادربرد ${b.mb.spec.ramType}`],
      [coolOk(b.cooler, b.cpu), `خنک‌کننده از سوکت و توان ${b.cpu.spec.tdp}W پردازنده پشتیبانی می‌کند`, 'خنک‌کننده با سوکت یا توان پردازنده سازگار نیست'],
      [caseOk(b.case, b.mb, b.gpu), 'مادربرد و کارت گرافیک در کیس جا می‌شوند', 'مادربرد یا کارت گرافیک در کیس جا نمی‌شود'],
      [b.psu.spec.watt >= need, `پاور ${b.psu.spec.watt}W ≥ توان موردنیاز تخمینی ${need}W`, `پاور ضعیف است (${b.psu.spec.watt}W < ${need}W)`],
      [!!(b.gpu || b.cpu.spec.igpu === 'بله'), b.gpu ? 'کارت گرافیک مجزا دارد' : 'تصویر از گرافیک داخلی پردازنده تأمین می‌شود', 'سیستم خروجی تصویر ندارد']
    ];
  }

  /* ---------- نمای صفحه ---------- */
  let opts = { purpose: 'gaming', budget: 60000000, brand: 'any', size: 'any', deco: false };
  let cur = null, minNeeded = null;

  App.routes.assembly = () => {
    app.innerHTML = `
      <div class="section-title"><h2>اسمبل هوشمند</h2><span class="kicker">بودجه‌ات را بگو، بقیه با ما</span></div>
      <div class="asm-layout">
        <aside class="panel asm-form">
          <div class="field"><label>هدف استفاده</label><select id="ap">${Object.entries(PURPOSES).map(([k, v]) => `<option value="${k}" ${opts.purpose === k ? 'selected' : ''}>${v.label}</option>`).join('')}</select></div>
          <div class="field"><label>بودجه کل: <span class="budget-out" id="abOut"></span></label>
            <input id="ab" type="range" min="20000000" max="300000000" step="1000000" value="${opts.budget}"></div>
          <div class="field"><label>برند پردازنده</label><select id="abr"><option value="any">فرقی نمی‌کند</option><option value="AMD" ${opts.brand === 'AMD' ? 'selected' : ''}>AMD</option><option value="Intel" ${opts.brand === 'Intel' ? 'selected' : ''}>Intel</option></select></div>
          <div class="field"><label>اندازه سیستم</label><select id="asz">
            <option value="any">فرقی نمی‌کند</option><option value="compact" ${opts.size === 'compact' ? 'selected' : ''}>جمع‌وجور (mATX/ITX)</option><option value="ITX" ${opts.size === 'ITX' ? 'selected' : ''}>خیلی کوچک (ITX)</option></select></div>
          <div class="field"><label style="display:flex;gap:8px;align-items:center;color:var(--text)"><input id="ad" type="checkbox" ${opts.deco ? 'checked' : ''}> افزودن قطعه تزئینی (در صورت بودجه)</label></div>
          <button class="btn btn-primary" id="abuild" style="width:100%">⚡ بساز</button>
          <p class="muted" style="margin-top:12px;font-size:.85rem">هزینه اسمبل و تست در قیمت نهایی لحاظ می‌شود. همه قطعات از نظر سوکت، رم، توان پاور و ابعاد کیس بررسی می‌شوند.</p>
        </aside>
        <section class="panel" id="asmResult"></section>
      </div>`;
    const out = () => ($('#abOut').textContent = toman(Number($('#ab').value)));
    out();
    $('#ab').addEventListener('input', out);
    $('#abuild').onclick = () => {
      opts = { purpose: $('#ap').value, budget: Number($('#ab').value), brand: $('#abr').value, size: $('#asz').value, deco: $('#ad').checked };
      run();
    };
    run();
  };

  function run() {
    const r = autoBuild(opts);
    cur = r.build; minNeeded = r.minNeeded;
    paint();
  }

  function paint() {
    const box = $('#asmResult');
    if (!cur) {
      box.innerHTML = `<div class="notice">با این بودجه و ترجیحات، سیستم سازگاری پیدا نشد.${minNeeded ? `<br>حداقل بودجه موردنیاز برای این انتخاب‌ها حدود <b>${toman(minNeeded)}</b> است.` : '<br>ترجیحات (برند/اندازه) را آزاد کنید یا موجودی انبار را بررسی کنید.'}</div>`;
      return;
    }
    const b = cur;
    const fee = Number(Store.db.settings.assemblyFee) || 0;
    const parts = sum(b);
    const total = parts + fee;
    const diff = opts.budget - total;
    const rows = ORDER.map((k) => {
      const c = Store.cat(k);
      const opt = altsFor(k, b);
      const sel = b[k];
      return `<div class="asm-row">
        <div class="cname"><i>${c.icon}</i>${c.name}</div>
        <select data-k="${k}">
          ${optional(k, b) ? `<option value="" ${!sel ? 'selected' : ''}>— بدون —</option>` : ''}
          ${opt.map((p) => `<option value="${p.id}" ${sel && sel.id === p.id ? 'selected' : ''}>${esc(p.brand + ' ' + p.name)} — ${fmt(fp(p))}</option>`).join('')}
        </select>
        <div class="p">${sel ? fmt(fp(sel)) + ' <small class="muted">تومان</small>' : '—'}</div></div>`;
    }).join('');
    box.innerHTML = `
      <h3 style="font-size:1.6rem">سیستم پیشنهادی برای «${PURPOSES[opts.purpose].label}»</h3>
      <p class="muted">هر قطعه را می‌توانید از لیست تغییر دهید؛ قیمت و بررسی سازگاری لحظه‌ای به‌روز می‌شود.</p>
      <div style="margin-top:8px">${rows}</div>
      <div class="totals">
        <div class="line"><span>جمع قطعات (با احتساب تخفیف‌ها)</span><span>${toman(parts)}</span></div>
        <div class="line"><span>هزینه اسمبل، تست و نصب ویندوز</span><span>${toman(fee)}</span></div>
        <div class="line grand"><span>قیمت نهایی سیستم</span><span>${toman(total)}</span></div>
        <div class="line"><span class="muted">${diff >= 0 ? 'باقی‌مانده از بودجه' : 'بیشتر از بودجه'}</span><span class="${diff >= 0 ? 'good' : 'warn'}">${toman(Math.abs(diff))}</span></div>
      </div>
      <ul class="check-list">${checks(b).map(([ok, y, n]) => `<li class="${ok ? '' : 'no'}">${ok ? y : n}</li>`).join('')}</ul>
      <div class="row" style="margin-top:18px"><button class="btn btn-primary" id="asmCart">🛒 افزودن کل سیستم به سبد</button><button class="btn btn-ghost" id="asmAgain">پیشنهاد دوباره</button></div>`;
    box.querySelectorAll('select[data-k]').forEach((s) => (s.onchange = () => { cur[s.dataset.k] = Store.product(s.value) || null; paint(); }));
    $('#asmAgain').onclick = run;
    $('#asmCart').onclick = () => {
      if (!checks(cur).every((c) => c[0]) && !confirm('برخی موارد سازگار نیستند. باز هم به سبد اضافه شود؟')) return;
      for (const k of ORDER) if (cur[k] && !App.Cart.add(cur[k].id)) return;
      App.Cart.add('ASM_FEE');
      App.toast('سیستم کامل به سبد اضافه شد ✔');
      location.hash = '#/cart';
    };
  }
})();
