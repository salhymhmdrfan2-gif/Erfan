/* =====================================================
   Erfan. — پنل مدیریت
   ورود: نام کاربری admin  /  رمز 1111
   (احراز هویت سمت کلاینت است؛ توضیحات در ARCHITECTURE.md)
   ===================================================== */
(() => {
  const ADMIN_USER = 'admin';
  const ADMIN_PASS = '1111';
  const SK = 'erfan_admin_session';
  const { esc, toman, fmt, finalPrice, discountPct } = Store;
  const $ = (s, r = document) => r.querySelector(s);
  const root = $('#root');
  let memAuth = false, tab = 'dash';
  const S = { pq: '', pc: '' };

  const authed = () => { try { return sessionStorage.getItem(SK) === '1'; } catch (e) { return memAuth; } };
  const setAuth = (v) => { memAuth = v; try { v ? sessionStorage.setItem(SK, '1') : sessionStorage.removeItem(SK); } catch (e) {} };

  function toast(msg, err) {
    const t = document.createElement('div');
    t.className = 'toast' + (err ? ' err' : '');
    t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }
  function modal(html) {
    const o = document.createElement('div');
    o.className = 'overlay';
    o.innerHTML = `<div class="modal"><button class="close" aria-label="بستن">×</button>${html}</div>`;
    o.addEventListener('click', (e) => { if (e.target === o || e.target.classList.contains('close')) o.remove(); });
    document.body.appendChild(o);
    return o;
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.overlay').forEach((o) => o.remove()); });

  /* ---------- Login ---------- */
  function loginView() {
    root.innerHTML = `<div class="login-wrap"><div class="panel login-box">
      <div class="logo">Erfan<span>.</span></div>
      <div class="kicker">پنل مدیریت</div>
      <form id="lf">
        <div class="field"><label>نام کاربری</label><input name="u" autocomplete="username" value="admin" required></div>
        <div class="field"><label>رمز عبور</label><input name="p" type="password" autocomplete="current-password" autofocus required></div>
        <button class="btn btn-primary" style="width:100%">ورود</button>
        <p id="le" class="bad" style="margin-top:10px;min-height:1.5em"></p>
      </form>
      <a href="index.html" class="muted">← بازگشت به فروشگاه</a></div></div>`;
    $('#lf').onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target);
      if (f.get('u') === ADMIN_USER && f.get('p') === ADMIN_PASS) { setAuth(true); panel(); }
      else $('#le').textContent = 'نام کاربری یا رمز عبور اشتباه است';
    };
  }

  /* ---------- Layout ---------- */
  const TABS = [['dash', '📊 داشبورد'], ['products', '📦 کالاها'], ['disc', '🏷️ تخفیف‌ها'], ['orders', '🧾 سفارش‌ها'], ['settings', '⚙️ تنظیمات']];
  function panel() {
    Store.load();
    root.innerHTML = `<div class="adm">
      <aside class="side"><div class="logo">Erfan<span>.</span></div><small>پنل مدیریت</small>
        ${TABS.map(([k, l]) => `<button class="nav-i ${k === tab ? 'active' : ''}" data-tab="${k}">${l}</button>`).join('')}
        <div class="grow"></div>
        <a class="nav-i btn btn-ghost" href="index.html" target="_blank" style="text-align:center">مشاهده سایت ↗</a>
        <button class="nav-i" id="logout">خروج</button></aside>
      <section class="content" id="tabc"></section></div>`;
    root.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => { tab = b.dataset.tab; panel(); }));
    $('#logout').onclick = () => { setAuth(false); loginView(); };
    ({ dash: tabDash, products: tabProducts, disc: tabDisc, orders: tabOrders, settings: tabSettings })[tab]();
  }

  /* ---------- Dashboard ---------- */
  function tabDash() {
    const db = Store.db;
    const valid = db.orders.filter((o) => o.status !== 'لغو شده');
    const revenue = valid.reduce((s, o) => s + o.total, 0);
    const low = db.products.filter((p) => p.stock <= 3).sort((a, b) => a.stock - b.stock);
    $('#tabc').innerHTML = `<h2>داشبورد</h2>
      <div class="stats">
        <div class="stat"><small>تعداد کالاها</small><b>${fmt(db.products.length)}</b></div>
        <div class="stat"><small>کالاهای تخفیف‌دار</small><b>${fmt(db.products.filter((p) => discountPct(p) > 0).length)}</b></div>
        <div class="stat"><small>سفارش‌ها</small><b>${fmt(db.orders.length)}</b></div>
        <div class="stat"><small>فروش کل</small><b style="font-size:1.2rem">${toman(revenue)}</b></div>
        <div class="stat"><small>کالای کم‌موجود (≤۳)</small><b class="${low.length ? 'warn' : ''}">${fmt(low.length)}</b></div>
      </div>
      <div class="two">
        <div class="panel"><h3>آخرین سفارش‌ها</h3>${db.orders.length ? `<table><tbody>${db.orders.slice(0, 6).map((o) => `<tr><td dir="ltr">${o.id}</td><td>${esc(o.customer.name)}</td><td>${toman(o.total)}</td><td><span class="pill">${o.status}</span></td></tr>`).join('')}</tbody></table>` : '<p class="muted">هنوز سفارشی ثبت نشده.</p>'}</div>
        <div class="panel"><h3>هشدار موجودی</h3>${low.length ? `<table><tbody>${low.slice(0, 8).map((p) => `<tr><td dir="auto">${esc(p.name)}</td><td class="${p.stock ? 'warn' : 'bad'}">${p.stock ? fmt(p.stock) + ' عدد' : 'ناموجود'}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">همه کالاها موجودی کافی دارند.</p>'}</div>
      </div>`;
  }

  /* ---------- Products ---------- */
  function specFields(cat, spec) {
    return (Store.db.specSchema[cat] || []).map((f) => {
      const v = spec[f.k] ?? '';
      const input = f.type === 'select'
        ? `<select name="s_${f.k}">${f.options.map((o) => `<option ${String(v) === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`
        : `<input name="s_${f.k}" type="${f.type === 'number' ? 'number' : 'text'}" value="${esc(v)}" ${f.type === 'number' ? 'step="any"' : ''}>`;
      return `<div class="field"><label>${esc(f.label)}</label>${input}</div>`;
    }).join('');
  }

  function productForm(id) {
    const db = Store.db;
    const old = id ? Store.product(id) : null;
    const p = old ? JSON.parse(JSON.stringify(old)) : { cat: 'cpu', name: '', brand: '', price: '', discount: 0, stock: 1, img: '', spec: {} };
    const m = modal(`<h3>${old ? 'ویرایش کالا' : 'کالای جدید'}</h3>
      <form id="pf"><div class="form-grid">
        <div class="field full"><label>نام کالا</label><input name="name" required value="${esc(p.name)}"></div>
        <div class="field"><label>برند</label><input name="brand" required value="${esc(p.brand)}"></div>
        <div class="field"><label>دسته‌بندی</label><select name="cat" ${old ? 'disabled' : ''}>${db.categories.map((c) => `<option value="${c.id}" ${c.id === p.cat ? 'selected' : ''}>${c.name}</option>`).join('')}</select></div>
        <div class="field"><label>قیمت (تومان)</label><input name="price" type="number" min="0" required value="${esc(p.price)}"></div>
        <div class="field"><label>تخفیف (٪)</label><input name="discount" type="number" min="0" max="90" value="${esc(p.discount)}"></div>
        <div class="field"><label>موجودی</label><input name="stock" type="number" min="0" required value="${esc(p.stock)}"></div>
        <div class="field"><label>آدرس تصویر (اختیاری)</label><input name="img" dir="ltr" value="${esc(p.img)}" placeholder="https://…"></div>
      </div>
      <h4 style="margin:6px 0 10px">مشخصات فنی</h4>
      <div class="form-grid" id="specs">${specFields(p.cat, p.spec)}</div>
      <div class="row" style="margin-top:14px"><button class="btn btn-primary">ذخیره</button><button type="button" class="btn btn-ghost" data-cancel>انصراف</button></div></form>`);
    const f = $('#pf', m);
    f.cat.onchange = () => ($('#specs', m).innerHTML = specFields(f.cat.value, {}));
    $('[data-cancel]', m).onclick = () => m.remove();
    f.onsubmit = (e) => {
      e.preventDefault();
      const cat = old ? old.cat : f.cat.value;
      const spec = {};
      (db.specSchema[cat] || []).forEach((fd) => {
        const v = f['s_' + fd.k].value;
        spec[fd.k] = fd.type === 'number' ? Number(v) : v.trim();
      });
      const data = { cat, name: f.name.value.trim(), brand: f.brand.value.trim(), price: Number(f.price.value), discount: Math.min(90, Math.max(0, Number(f.discount.value) || 0)),
        stock: Math.max(0, Math.floor(Number(f.stock.value) || 0)), img: f.img.value.trim(), spec };
      if (!data.name || !(data.price > 0)) return toast('نام و قیمت معتبر وارد کنید', true);
      if (old) Object.assign(old, data);
      else db.products.push({ id: 'p' + Date.now().toString(36), ...data });
      Store.save(); m.remove(); toast('ذخیره شد ✔'); tabProducts();
    };
  }

  function tabProducts() {
    const db = Store.db;
    $('#tabc').innerHTML = `<div class="row" style="justify-content:space-between;margin-bottom:14px"><h2 style="margin:0">کالاها</h2><button class="btn btn-primary" id="addP">+ کالای جدید</button></div>
      <div class="row" style="margin-bottom:14px"><input id="pq" style="max-width:320px" placeholder="جستجو نام/برند…" value="${esc(S.pq)}">
        <select id="pc" style="max-width:240px"><option value="">همه دسته‌ها</option>${db.categories.map((c) => `<option value="${c.id}" ${S.pc === c.id ? 'selected' : ''}>${c.name}</option>`).join('')}</select></div>
      <div class="panel table-wrap" id="ptbl"></div>`;
    const paint = () => {
      const q = S.pq.trim().toLowerCase();
      const items = db.products.filter((p) => (!S.pc || p.cat === S.pc) && (!q || (p.name + ' ' + p.brand).toLowerCase().includes(q)));
      $('#ptbl').innerHTML = `<table><thead><tr><th>نام</th><th>دسته</th><th>قیمت</th><th>تخفیف</th><th>قیمت نهایی</th><th>موجودی</th><th></th></tr></thead><tbody>
        ${items.map((p) => `<tr><td dir="auto"><b>${esc(p.name)}</b><br><small class="muted">${esc(p.brand)}</small></td><td>${Store.cat(p.cat).name}</td><td>${fmt(p.price)}</td>
        <td>${p.discount ? '٪' + fmt(p.discount) : '—'}</td><td class="good">${fmt(finalPrice(p))}</td><td class="${p.stock <= 3 ? 'warn' : ''}">${fmt(p.stock)}</td>
        <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-edit="${p.id}">ویرایش</button> <button class="btn btn-danger btn-sm" data-del="${p.id}">حذف</button></td></tr>`).join('')}
        </tbody></table>${items.length ? '' : '<div class="empty">موردی نیست</div>'}`;
      $('#ptbl').querySelectorAll('[data-edit]').forEach((b) => (b.onclick = () => productForm(b.dataset.edit)));
      $('#ptbl').querySelectorAll('[data-del]').forEach((b) => (b.onclick = () => {
        const p = Store.product(b.dataset.del);
        if (!confirm(`«${p.name}» حذف شود؟`)) return;
        db.products.splice(db.products.indexOf(p), 1); Store.save(); toast('حذف شد'); paint();
      }));
    };
    $('#addP').onclick = () => productForm();
    $('#pq').oninput = (e) => { S.pq = e.target.value; paint(); };
    $('#pc').onchange = (e) => { S.pc = e.target.value; paint(); };
    paint();
  }

  /* ---------- Discounts ---------- */
  function tabDisc() {
    const db = Store.db;
    const discounted = db.products.filter((p) => p.discount > 0);
    $('#tabc').innerHTML = `<h2>مدیریت تخفیف‌ها</h2>
      <div class="two">
        <div class="panel"><h3>جشنواره سراسری</h3><p class="muted" style="margin-bottom:10px">روی همه کالاها اعمال می‌شود (اگر تخفیف خود کالا بیشتر باشد، همان معتبر است). ۰ = غیرفعال</p>
          <div class="row" style="flex-wrap:nowrap"><input id="gs" type="number" min="0" max="90" value="${esc(db.settings.globalSale)}"><button class="btn btn-primary" id="gsb">ثبت</button></div></div>
        <div class="panel"><h3>تخفیف گروهی روی یک دسته</h3>
          <div class="row" style="flex-wrap:nowrap"><select id="bc"><option value="*">همه دسته‌ها</option>${db.categories.map((c) => `<option value="${c.id}">${c.name}</option>`).join('')}</select><input id="bp" type="number" min="0" max="90" placeholder="٪" style="max-width:90px"><button class="btn btn-primary" id="bb">اعمال</button></div></div>
      </div>
      <div class="panel"><h3>کدهای تخفیف</h3><div class="table-wrap"><table><thead><tr><th>کد</th><th>درصد</th><th>وضعیت</th><th></th></tr></thead><tbody>
        ${db.coupons.map((c, i) => `<tr><td dir="ltr"><b>${esc(c.code)}</b></td><td>٪${fmt(c.percent)}</td><td><button class="pill ${c.active ? 'on' : 'off'}" data-tg="${i}" style="cursor:pointer">${c.active ? 'فعال' : 'غیرفعال'}</button></td><td><button class="btn btn-danger btn-sm" data-dc="${i}">حذف</button></td></tr>`).join('')}
        </tbody></table></div>
        <form id="cf" class="row" style="margin-top:14px;flex-wrap:nowrap"><input name="code" placeholder="کد (مثلاً SPRING15)" dir="ltr" required><input name="percent" type="number" min="1" max="90" placeholder="درصد" required style="max-width:110px"><button class="btn btn-primary">افزودن کد</button></form></div>
      <div class="panel"><h3>کالاهای دارای تخفیف (${fmt(discounted.length)})</h3><div class="table-wrap"><table><thead><tr><th>کالا</th><th>تخفیف ٪</th><th>قیمت نهایی</th><th></th></tr></thead><tbody>
        ${discounted.map((p) => `<tr><td dir="auto">${esc(p.name)}</td><td><input type="number" min="0" max="90" value="${p.discount}" data-pd="${p.id}"></td><td class="good">${fmt(finalPrice(p))}</td><td><button class="btn btn-ghost btn-sm" data-rd="${p.id}">حذف تخفیف</button></td></tr>`).join('') || '<tr><td colspan="4" class="muted">کالایی تخفیف ندارد</td></tr>'}
        </tbody></table></div></div>`;
    $('#gsb').onclick = () => { db.settings.globalSale = Math.min(90, Math.max(0, Number($('#gs').value) || 0)); Store.save(); toast('ثبت شد ✔'); };
    $('#bb').onclick = () => {
      const c = $('#bc').value, v = Math.min(90, Math.max(0, Number($('#bp').value) || 0));
      let n = 0; db.products.forEach((p) => { if (c === '*' || p.cat === c) { p.discount = v; n++; } });
      Store.save(); toast(`تخفیف روی ${fmt(n)} کالا اعمال شد`); tabDisc();
    };
    $('#cf').onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target); const code = f.get('code').trim().toUpperCase();
      if (db.coupons.some((c) => c.code === code)) return toast('این کد قبلاً وجود دارد', true);
      db.coupons.push({ code, percent: Math.min(90, Number(f.get('percent'))), active: true }); Store.save(); tabDisc();
    };
    document.querySelectorAll('[data-tg]').forEach((b) => (b.onclick = () => { const c = db.coupons[b.dataset.tg]; c.active = !c.active; Store.save(); tabDisc(); }));
    document.querySelectorAll('[data-dc]').forEach((b) => (b.onclick = () => { db.coupons.splice(b.dataset.dc, 1); Store.save(); tabDisc(); }));
    document.querySelectorAll('[data-pd]').forEach((i) => (i.onchange = () => { Store.product(i.dataset.pd).discount = Math.min(90, Math.max(0, Number(i.value) || 0)); Store.save(); tabDisc(); }));
    document.querySelectorAll('[data-rd]').forEach((b) => (b.onclick = () => { Store.product(b.dataset.rd).discount = 0; Store.save(); tabDisc(); }));
  }

  /* ---------- Orders ---------- */
  const STATUS = ['جدید', 'در حال آماده‌سازی', 'ارسال شده', 'تحویل شده', 'لغو شده'];
  function tabOrders() {
    const db = Store.db;
    $('#tabc').innerHTML = `<h2>سفارش‌ها</h2><div class="panel table-wrap">${db.orders.length ? `<table><thead><tr><th>کد</th><th>تاریخ</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th></th></tr></thead><tbody>
      ${db.orders.map((o) => `<tr><td dir="ltr">${o.id}</td><td>${new Date(o.date).toLocaleDateString('fa-IR')}</td><td>${esc(o.customer.name)}<br><small class="muted" dir="ltr">${esc(o.customer.phone)}</small></td><td>${toman(o.total)}</td>
      <td><select data-st="${o.id}">${STATUS.map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
      <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-vo="${o.id}">جزئیات</button> <button class="btn btn-danger btn-sm" data-do="${o.id}">حذف</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">هنوز سفارشی ثبت نشده است.</div>'}</div>`;
    document.querySelectorAll('[data-st]').forEach((s) => (s.onchange = () => { db.orders.find((o) => o.id === s.dataset.st).status = s.value; Store.save(); toast('وضعیت به‌روز شد'); }));
    document.querySelectorAll('[data-do]').forEach((b) => (b.onclick = () => { if (!confirm('سفارش حذف شود؟')) return; db.orders = db.orders.filter((o) => o.id !== b.dataset.do); Store.save(); tabOrders(); }));
    document.querySelectorAll('[data-vo]').forEach((b) => (b.onclick = () => {
      const o = db.orders.find((x) => x.id === b.dataset.vo);
      modal(`<h3 dir="ltr">${o.id}</h3><p class="muted">${esc(o.customer.name)} — ${esc(o.customer.phone)}<br>${esc(o.customer.address)}</p>
        <table style="margin-top:10px"><tbody>${o.items.map((i) => `<tr><td dir="auto">${esc(i.name)}</td><td>× ${fmt(i.qty)}</td><td>${fmt(i.unit * i.qty)}</td></tr>`).join('')}</tbody></table>
        <div class="totals"><div class="line"><span>جمع</span><span>${toman(o.subtotal)}</span></div>${o.coupon ? `<div class="line"><span>کد ${esc(o.coupon)}</span><span class="good">− ${toman(o.couponDiscount)}</span></div>` : ''}<div class="line grand"><span>مبلغ نهایی</span><span>${toman(o.total)}</span></div></div>`);
    }));
  }

  /* ---------- Settings ---------- */
  function tabSettings() {
    const db = Store.db;
    $('#tabc').innerHTML = `<h2>تنظیمات</h2>
      <div class="panel"><form id="sf" class="form-grid">
        <div class="field"><label>هزینه اسمبل و تست (تومان)</label><input name="fee" type="number" min="0" value="${esc(db.settings.assemblyFee)}"></div>
        <div class="field"><label>تلفن پشتیبانی</label><input name="phone" value="${esc(db.settings.phone)}"></div>
        <div class="full"><button class="btn btn-primary">ذخیره تنظیمات</button></div></form></div>
      <div class="panel"><h3>پشتیبان‌گیری و بازنشانی</h3><p class="muted" style="margin-bottom:12px">داده‌ها فقط در مرورگر همین دستگاه ذخیره می‌شوند؛ از آن‌ها نسخه پشتیبان بگیرید.</p>
        <div class="row"><button class="btn btn-ghost" id="ex">⬇ خروجی JSON</button><label class="btn btn-ghost" style="margin:0;cursor:pointer">⬆ ورود JSON<input id="im" type="file" accept=".json" hidden></label><button class="btn btn-danger" id="rs">بازنشانی به داده‌های اولیه</button></div></div>`;
    $('#sf').onsubmit = (e) => { e.preventDefault(); db.settings.assemblyFee = Math.max(0, Number(e.target.fee.value) || 0); db.settings.phone = e.target.phone.value.trim(); Store.save(); toast('ذخیره شد ✔'); };
    $('#ex').onclick = () => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' }));
      a.download = 'erfan-backup.json'; a.click(); URL.revokeObjectURL(a.href);
    };
    $('#im').onchange = (e) => {
      const file = e.target.files[0]; if (!file) return;
      const r = new FileReader();
      r.onload = () => { try { const o = JSON.parse(r.result); if (!Array.isArray(o.products) || !o.settings) throw 0; Store.replace(o); toast('ورود داده انجام شد ✔'); tabSettings(); } catch (x) { toast('فایل معتبر نیست', true); } };
      r.readAsText(file);
    };
    $('#rs').onclick = () => { if (confirm('همه داده‌ها (کالاها، سفارش‌ها، کدها) به حالت اولیه برگردد؟')) { Store.reset(); toast('بازنشانی شد'); tabSettings(); } };
  }

  authed() ? panel() : loginView();
})();
